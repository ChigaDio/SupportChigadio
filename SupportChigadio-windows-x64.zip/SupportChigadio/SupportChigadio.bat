@echo off
setlocal
cd /d "%~dp0"
if exist "SupportChigadio.exe" (
  start "" "SupportChigadio.exe"
  exit /b 0
)
if not exist "main-support\SupportChigadio.exe" (
  echo Error: main-support\SupportChigadio.exe が見つかりません
  pause
  exit /b 1
)
echo 初回セットアップ中...
xcopy /E /I /Y "main-support\*" "." >nul
start "" "SupportChigadio.exe"
