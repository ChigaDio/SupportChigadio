#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
xattr -cr "$ROOT" 2>/dev/null || true
if [ -x "./SupportChigadio" ]; then
  if ! codesign --verify "./SupportChigadio" 2>/dev/null; then
    codesign --force --sign - "./SupportChigadio" 2>/dev/null || true
  fi
  exec "./SupportChigadio"
fi
ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  SRC="arm64/main-support"
else
  SRC="x64/main-support"
fi
if [ ! -d "$SRC" ]; then
  echo "エラー: 対応する実行ファイルが見つかりません ($SRC)"
  read -r -p "Enterキーで終了..."
  exit 1
fi
echo "初回セットアップ中... ($ARCH)"
cp -R "$SRC"/* .
chmod +x ./SupportChigadio
codesign --force --sign - ./SupportChigadio 2>/dev/null || true
exec ./SupportChigadio
